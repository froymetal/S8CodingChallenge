/*
 Coding Challenge

 Given two strings, determine if they share a common substring. A substring may be as small as one character.
 Example:
 String1 = “art”
 String 2 = “ammo”
 Both string share ‘a’, so return true;
 Example 2:
 String1 = “be”
 String 2 = “cat”
 No characters are shared, so return false;

 Bonus: Can you return the length of the longest substring shared by the two strings?
 Example:
 S1 = “wonderful”
 S2 = “fulsome”
 Both words share “ful”, so return 3

 */

import Foundation

func compareString(s1: String, s2: String) -> (Bool, Int) {

    // Force to lowercase to make comparison
    let s1 = s1.lowercased()
    let s2 = s2.lowercased()

    // Make first validation
    if s1 == s2 { return (true, s1.count) }

    var result = [String]()
    let min = s1.count < s2.count ? s1 : s2
    let max = min == s1 ? s2 : s1

    for (index, _) in min.enumerated() {
        for j in (0..<index) {
            let array = min.map { String($0) }
            let newString = array[j...index].joined()
            if max.contains(newString) {
                result.append(newString)
            }
        }
    }

    // removing duplicates
    result = Array(Set(result))
    result = result.sorted(by: { s1, s2 in
        return s1.count > s2.count
    })

    let first = result.first ?? ""
    let isSubString = first.isEmpty ? false : true
    return (isSubString, first.count)
}

//let result = compareCommonSubstring(string1: "art", string2: "artmmo")
let substringTuple = compareString(s1: "wonderful", s2: "fulsome")
print(substringTuple.0)
print(substringTuple.1)
